def handler event
  render css: File.read('style.css')
end
